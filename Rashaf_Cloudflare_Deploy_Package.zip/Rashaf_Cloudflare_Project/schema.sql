CREATE TABLE IF NOT EXISTS messages (id TEXT PRIMARY KEY,name TEXT NOT NULL,email TEXT,subject TEXT NOT NULL,message TEXT NOT NULL,photos TEXT NOT NULL DEFAULT '[]',created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);
