export async function onRequestPost({request,env}) {
 if(!env.DB||!env.MEDIA)return Response.json({error:"لم يتم إعداد قاعدة البيانات والتخزين في Cloudflare بعد."},{status:503});
 try { const f=await request.formData(); if(String(f.get("website")||"").trim())return Response.json({ok:true});
 const name=String(f.get("name")||"").trim().slice(0,100),email=String(f.get("email")||"").trim().slice(0,200),subject=String(f.get("subject")||"").trim().slice(0,160),message=String(f.get("message")||"").trim().slice(0,5000);
 if(!name||!subject||!message)return Response.json({error:"يرجى تعبئة الاسم والموضوع والرسالة."},{status:400});
 const files=f.getAll("photos").filter(x=>x&&typeof x.arrayBuffer==="function"&&x.size>0);if(files.length>4||files.some(x=>x.size>5242880))return Response.json({error:"الحد الأقصى 4 صور، 5 ميغابايت للصورة."},{status:400});
 const keys=[];for(const file of files){if(!["image/jpeg","image/png","image/webp"].includes(file.type))return Response.json({error:"نوع الصورة غير مدعوم."},{status:400});const ext=file.type==="image/png"?"png":file.type==="image/webp"?"webp":"jpg",key="visitor-uploads/"+crypto.randomUUID()+"."+ext;await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType:file.type}});keys.push(key)}
 const id=crypto.randomUUID();await env.DB.prepare("INSERT INTO messages (id,name,email,subject,message,photos,created_at) VALUES (?,?,?,?,?,?,?)").bind(id,name,email,subject,message,JSON.stringify(keys),new Date().toISOString()).run();return Response.json({ok:true});
 }catch(e){return Response.json({error:"تعذر حفظ الرسالة. يرجى المحاولة لاحقاً."},{status:500})}
}