export async function onRequestGet({request,env}){
 const u=new URL(request.url); const key=u.searchParams.get("key");
 if(key){if(!key.startsWith("gallery/")||key.includes(".."))return new Response("Bad key",{status:400});if(!env.MEDIA)return new Response("Storage not configured",{status:503});const o=await env.MEDIA.get(key);if(!o)return new Response("Not found",{status:404});return new Response(o.body,{headers:{"Content-Type":o.httpMetadata?.contentType||"image/jpeg","Cache-Control":"public, max-age=3600","X-Content-Type-Options":"nosniff"}})}
 const raw=env.SITE_KV?await env.SITE_KV.get("gallery-photos"):null;return Response.json({photos:raw?JSON.parse(raw):[]},{headers:{"Cache-Control":"no-store"}});
}
